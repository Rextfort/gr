from django.shortcuts import render

def inicio(request):
    return render(request, 'inicio.html')

def servicios(request):
    return render(request, 'servicios.html')

def galeria(request):
    return render(request, 'galeria.html')

def contacto(request):
    return render(request, 'contacto.html')